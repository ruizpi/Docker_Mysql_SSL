# Create the client-side certificates

OPENSSL_CLIENT=$1

#docker run --rm -v $PWD/certs:/certs -it nginx 
openssl req -newkey rsa:2048 -days 3600 -nodes -subj "${OPENSSL_CLIENT}" -keyout ./etc/certs/client-key.pem -out ./etc/certs/client-req.pem

#docker run --rm -v $PWD/certs:/certs -it nginx 
openssl rsa -in ./etc/certs/client-key.pem -out ./etc/certs/client-key.pem

#docker run --rm -v $PWD/certs:/certs -it nginx 
openssl x509 -req -in ./etc/certs/client-req.pem -days 3600 -CA ./etc/certs/root-ca.pem -CAkey ./etc/certs/root-ca-key.pem -set_serial 01 -out ./etc/certs/client-cert.pem

# Verify the certificates are correct
#docker run --rm -v $PWD/certs:/certs -it nginx 
#openssl verify -CAfile /certs/root-ca.pem /certs/client-cert.pem