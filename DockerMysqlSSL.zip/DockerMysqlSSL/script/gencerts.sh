mkdir -p certs

OPENSSL_SUBJ="/C=US/ST=California/L=Santa Clara"
OPENSSL_CA="${OPENSSL_SUBJ}/CN=fake-CA"
OPENSSL_SERVER="${OPENSSL_SUBJ}/CN=fake-server"
OPENSSL_CLIENT="${OPENSSL_SUBJ}/CN=fake-client"

sh ./script/genroot.sh "${OPENSSL_CA}"
sh ./script/genserver.sh "${OPENSSL_SERVER}"
sh ./script/genclient.sh "${OPENSSL_CLIENT}"